package com.example.finalproject.ultil;

public class Server {
    //10.80.254.63
    public static String localhost = "10.10.111.231";
    public static String urlCategory = "http://"+ localhost + ":8080/server/GetCategory.php?_ijt=k8r11l8j0tikof6v308jfcpgrf";
    public static String urlNewProduct = "http://"+ localhost + ":8080/server/getNewProduct.php?_ijt=iuk4hskn5fav17lbl7evvkj5k0";
    public static String urlSoMiNam = "http://"+ localhost + ":8080/server/getProduct.php?page=";
}
